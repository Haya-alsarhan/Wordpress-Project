<footer>
  <div class="Rights">
© 2017 HA AND YA. All Rights Reserved.
</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
